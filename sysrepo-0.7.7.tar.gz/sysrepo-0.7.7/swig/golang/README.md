## Requirements

* go >= 1.4
* sysrepo installed with dependencies

## Install

```
$ cd ./examples/application_example
$ go build
```

## Usage

```
$ ./application_example
```
